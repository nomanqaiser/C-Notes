# include<stdio.h>
/*
This is our first c program
which is awesome!
*/
int main(){
    int tom;
    int Tom;
    // Declaring variables to store error codes
    int error_code;
    // 'J' --> a character
    printf("Hello I am learning C with Harry");
    return 0;
}